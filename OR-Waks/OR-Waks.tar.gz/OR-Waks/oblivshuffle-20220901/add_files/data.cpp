#include <iostream>
#include <fstream>
#include <random>
#include <vector>
#include <string>

int main(int argc, char* argv[]) {
    if (argc != 4) {
        std::cerr << "Usage: " << argv[0] << " <output_file> <n> <d>\n";
        return 1;
    }

    std::string filename = argv[1];
    size_t n = std::stoull(argv[2]);
    int d = std::stoi(argv[3]);

    if (n == 0 || d <= 0) {
        std::cerr << "Error: n must be > 0 and d must be > 0\n";
        return 1;
    }

    std::ofstream ofs(filename);
    if (!ofs) {
        std::cerr << "Error: cannot open file for writing: " << filename << "\n";
        return 1;
    }

    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dist(1, d);

    for (size_t i = 0; i < n; ++i) {
        ofs << dist(gen);
        if (i + 1 < n) ofs << " ";
    }

    std::cout << "Generated " << n << " random integers (1.." << d << ") to " << filename << "\n";
    return 0;
}

