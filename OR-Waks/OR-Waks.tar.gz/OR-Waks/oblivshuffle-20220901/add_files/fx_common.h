
#pragma once
#include <cstdint>

using u32 = uint32_t;
using u64 = uint64_t;
using i64 = int64_t;
using u128 = unsigned __int128;
using i128 = __int128;

constexpr int FRAC = 32;
constexpr i64 ONE = (i64)1 << FRAC;
constexpr u64 FRAC_MASK = ((u64)ONE - 1ULL);
constexpr int NU_MAX = 128;
