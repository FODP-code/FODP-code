#pragma once
#include "util_obl.h"

u32 AGeo_oblivious(i64 r_fx, int nu, i64 ql_fx, i64 qr_fx);

u32 one_Geo_oblivious(i64 r_q32, i64 q1_q32);
