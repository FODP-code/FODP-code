#include <cmath>
#include <limits>
#include <cstdint>
#include <iostream>
#include <random>


// epsilon(d, xi1, xi2, lam)
double epsilon(double d, double xi1, double xi2, int lam) {
    return std::log((d + (1.0 + xi1) * lam) / ((1.0 - xi2) * lam));
}

// delta(d, xi1, xi2, lam)
double delta(double d, double xi1, double xi2, int lam) {
    double term1 = std::exp(-(xi1 * xi1 * lam) / ((2.0 + xi1) * d));
    double term2 = std::exp(-(xi2 * xi2 * lam) / (2.0 * d));
    return term1 + term2;
}

// best_lambda
int find_min_lambda(int d,
                          double eps_max,
                          double delta_max,
                          double xi_step,
                          int lambda_max)
{
    int best_lambda = -1;

    // xi1: xi_step ～ 1.0
    for (double xi1 = xi_step; xi1 <= 1.0 + 1e-12; xi1 += xi_step) {

        // xi2: xi_step ～ < 1.0
        for (double xi2 = xi_step; xi2 < 1.0 - 1e-12; xi2 += xi_step) {

            // Exponential search
            int lam = 1;
            bool ok = false;

            while (lam <= lambda_max) {
                double eps = epsilon(d, xi1, xi2, lam);
                double delt = delta(d, xi1, xi2, lam);

                if (eps <= eps_max && delt <= delta_max) {
                    ok = true;
                    break;
                }
                lam *= 2;
            }

            if (!ok) continue;

            // Binary search between lam/2 and lam
            int low = lam / 2;  
            int high = lam;

            while (low + 1 < high) {
	      int mid = (low + high) / 2;  // no overflow 
                if (epsilon(d, xi1, xi2, mid) <= eps_max &&
                    delta(d, xi1, xi2, mid) <= delta_max) {
                    high = mid;
                } else {
                    low = mid;
                }
            }

            int lam_candidate = high;

            if (best_lambda == -1 || lam_candidate < best_lambda) {
                best_lambda = lam_candidate;
            }
        }
    }

    return best_lambda;
}


// random in 1 to x
int randomInt(int x) {
    static std::random_device rd;   // seed
    static std::mt19937 gen(rd()); // MT
    std::uniform_int_distribution<> dist(1, x);
    return dist(gen);
}


bool isPrime(int number) {
    if (number <= 1) {
        return false;
    }
    if (number == 2) {
        return true;
    }
    if (number % 2 == 0) {
        return false;
    }

    int limit = static_cast<int>(std::sqrt(number));
    for (int i = 3; i <= limit; i += 2) {
        if (number % i == 0) {
            return false;
        }
    }
    return true;
}

int findPrimeInRange(int d) {
    for (int i = d; i < 2 * d; i++) {
        if (isPrime(i)) {
            return i;
        }
    }
    return -1;
}


// --------------------------------------------------
// oblivious hash
// （__uint128_t + %）
// --------------------------------------------------
uint32_t oblivious_hash(uint32_t x,
                        uint32_t a1,
                        uint32_t a0,
                        uint32_t p,
                        uint32_t b)  // b = n
{
    __uint64_t acc = (__uint64_t)a1 * x + a0;
    uint32_t y = (uint32_t)(acc % p);
    y = y % b;
    return y;
}


std::vector<uint32_t> apply_hash(
    const std::vector<uint32_t>& x,
    uint32_t a1,
    uint32_t a0,
    uint32_t p,
    uint32_t b
) {
    std::vector<uint32_t> y;
    y.reserve(x.size());

    for (uint32_t xi : x) {
        y.push_back(
            oblivious_hash(xi, a1, a0, p, b)
        );
    }
    return y;
}
