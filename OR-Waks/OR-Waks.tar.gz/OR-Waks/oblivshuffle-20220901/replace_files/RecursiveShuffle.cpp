//#include "RecursiveShuffle.hpp"

#include <vector>
#include <cstdint>
#include <cstring>
#include <string>
#include <inttypes.h>

#include <sgx_trts.h>  //aoi                                                                                                      
#include <numeric>
#include <cmath>

#include "fx_common.h"
#include "util_obl.h"
#include "parameter_gen.h"
#include "parameter_set.h"
#include "geo_dist.h"

#ifndef BEFTS_MODE
#include <array>
#include <sgx_tcrypto.h>
#include "../oasm_lib.h"
#include "../utils.hpp"
#include "../ObliviousPrimitives.hpp"
#include "RecursiveShuffle.hpp"
#endif

size_t RS_RB_BUFFER_SIZE;
bool *selected_list;
unsigned char *random_bytes_buffer = NULL;
uint32_t *random_bytes_buffer_ptr;
uint32_t *random_bytes_buffer_ptr_end;

/*
  MarkHalf: Marks half of the elements of an N sized array randomly.
  Pass in a bool array of size N, which will be populated with 1's at indexes which 
  r get marked by MarkHalf
  NOTE: MarkHalf assumes selected_list is initialized to all 0's before passed to MarkHalf
*/

void MarkHalf(uint64_t N, bool *selected_list) {
  
    uint64_t left_to_mark = N/2;
    uint64_t total_left = N;
    PRB_buffer *randpool = PRB_pool + g_thread_id;
    uint32_t coins[RS_MARKHALF_MAX_COINS];
    size_t coinsleft=0;
  
    FOAV_SAFE_CNTXT(MarkHalf_marking_half, N)
	for(uint64_t i=0; i<N; i++){
	    FOAV_SAFE2_CNTXT(MarkHalf_marking_half, i, coinsleft)
		if (coinsleft == 0) {
		    size_t numcoins = (N-i);
		    FOAV_SAFE_CNTXT(MarkHalf_marking_half, numcoins)
			if (numcoins > RS_MARKHALF_MAX_COINS) {
			    numcoins = RS_MARKHALF_MAX_COINS;
			}
		    randpool->getRandomBytes((unsigned char *) coins,
					     sizeof(coins[0])*numcoins);
		    coinsleft = numcoins;
		}
	    //Mark with probability left_to_mark/total_left;
	    uint32_t random_coin;
	    random_coin = (total_left * coins[--coinsleft]) >> 32;
	    uint32_t mark_threshold = total_left - left_to_mark;
	    uint8_t mark_element = oge_set_flag(random_coin, mark_threshold);

	    //If mark_element, obliviously set selected_list[i] to 1
	    FOAV_SAFE_CNTXT(MarkHalf_marking_half, i)
		selected_list[i] = mark_element;
	    left_to_mark-= mark_element;
	    total_left--;
	    FOAV_SAFE2_CNTXT(MarkHalf_marking_half, i, N)
		}
  
}

#ifndef BEFTS_MODE
void RecursiveShuffle_M1(unsigned char *buf, uint64_t N, size_t block_size) {
    FOAV_SAFE2_CNTXT(RS_M1, N, block_size)
	size_t num_random_bytes = calculatelog2(N) * N * sizeof(uint32_t);
#ifdef RS_M2_MEM_OPT1
    FOAV_SAFE2_CNTXT(RS_M1, num_random_bytes, RS_RB_BUFFER_LIMIT)
	if(num_random_bytes > RS_RB_BUFFER_LIMIT) {
	    RS_RB_BUFFER_SIZE = RS_RB_BUFFER_LIMIT;
	}
	else{
	    RS_RB_BUFFER_SIZE = num_random_bytes;
	}
    try {
        random_bytes_buffer = new unsigned char[RS_RB_BUFFER_SIZE];
        //FOAV_SAFE_CNTXT(RS_M1_initializing_selected_list, N)
        selected_list = new bool[N]{};
    } catch (std::bad_alloc&){
        printf("Allocating memory failed in RS_M2\n");
    }
    getBulkRandomBytes((unsigned char*)random_bytes_buffer, RS_RB_BUFFER_SIZE);
    random_bytes_buffer_ptr_end = (uint32_t*)(random_bytes_buffer + RS_RB_BUFFER_SIZE);
#else
    try {
        random_bytes_buffer = new unsigned char[num_random_bytes];
        selected_list = new bool[N]{};
    } catch (std::bad_alloc&){
        printf("Allocating memory failed in RS_M2\n");
    }

    getBulkRandomBytes((unsigned char*)random_bytes_buffer, num_random_bytes);
#endif

    random_bytes_buffer_ptr = (uint32_t*) random_bytes_buffer;
    FOAV_SAFE_CNTXT(RS_M1_branching_on_block_size_for_OSwap_Style_templates, block_size)
	if(block_size==4){
	    FOAV_SAFE_CNTXT(RS_M1_branching_on_block_size_for_OSwap_Style_templates, block_size)
		RecursiveShuffle_M1_inner<OSWAP_4>(buf, N, block_size, selected_list);
	    FOAV_SAFE_CNTXT(RS_M1_branching_on_block_size_for_OSwap_Style_templates, block_size)
		} else if(block_size==8){
	    FOAV_SAFE_CNTXT(RS_M1_branching_on_block_size_for_OSwap_Style_templates, block_size)
		RecursiveShuffle_M1_inner<OSWAP_8>(buf, N, block_size, selected_list);
	    FOAV_SAFE_CNTXT(RS_M1_branching_on_block_size_for_OSwap_Style_templates, block_size)
		} else if(block_size%16==0) {
	    FOAV_SAFE_CNTXT(RS_M1_branching_on_block_size_for_OSwap_Style_templates, block_size)
		RecursiveShuffle_M1_inner<OSWAP_16X>(buf, N, block_size, selected_list);
	    FOAV_SAFE_CNTXT(RS_M1_branching_on_block_size_for_OSwap_Style_templates, block_size)
		} else {
	    FOAV_SAFE_CNTXT(RS_M1_branching_on_block_size_for_OSwap_Style_templates, block_size)
		RecursiveShuffle_M1_inner<OSWAP_8_16X>(buf, N, block_size, selected_list);
	    FOAV_SAFE_CNTXT(RS_M1_branching_on_block_size_for_OSwap_Style_templates, block_size)
		}

    FOAV_SAFE_CNTXT(RecursiveShuffle_M1_delete, random_bytes_buffer)
	delete []random_bytes_buffer;
    FOAV_SAFE_CNTXT(RecursiveShuffle_M1_delete, selected_list)
	delete []selected_list;
}
#endif

void RecursiveShuffle_M2(unsigned char *buf, uint64_t N, size_t block_size){
    RecursiveShuffle_M2_parallel(buf, N, block_size, 1);
}

void RecursiveShuffle_M2_parallel(unsigned char *buf, uint64_t N, size_t block_size, size_t nthreads){
    FOAV_SAFE2_CNTXT(RS_M2, N, block_size)
	try {
	    selected_list = new bool[N]{};
	} catch (std::bad_alloc&){
	    printf("Allocating memory failed in RS_M2\n");
	}

    threadpool_init(nthreads);

    FOAV_SAFE_CNTXT(RS_M2_branching_on_block_size_for_OSwap_Style_templates, block_size)
	if(block_size==4){
	    RecursiveShuffle_M2_inner_parallel<OSWAP_4>(buf, N, block_size, selected_list, nthreads);
	} else if(block_size==8){
	    RecursiveShuffle_M2_inner_parallel<OSWAP_8>(buf, N, block_size, selected_list, nthreads);
	} else if(block_size%16==0) {
	    RecursiveShuffle_M2_inner_parallel<OSWAP_16X>(buf, N, block_size, selected_list, nthreads);
	} else {
	    RecursiveShuffle_M2_inner_parallel<OSWAP_8_16X>(buf, N, block_size, selected_list, nthreads);
	}
  
    threadpool_shutdown();

    FOAV_SAFE_CNTXT(RecursiveShuffle_M2_delete, selected_list)
	delete []selected_list;
}

// We maintain a double type return version of RecusiveShuffle_M2, 
// to time strictly the RS_M2 component when using it without any encryption or decryption
// We need this only for the BOS optimizer!!
double RecursiveShuffle_M2_opt(unsigned char *buf, uint64_t N, size_t block_size){
    FOAV_SAFE2_CNTXT(RS_M2_opt, N, block_size)
	//In a single call allocate all the randomness we need here!
	size_t num_random_bytes = calculatelog2(N) * N * sizeof(uint32_t);
    long t0, t1;
    ocall_clock(&t0);

#ifdef RS_M2_MEM_OPT1
    if(num_random_bytes > RS_RB_BUFFER_LIMIT) {
	RS_RB_BUFFER_SIZE = RS_RB_BUFFER_LIMIT;
    }
    else{
	RS_RB_BUFFER_SIZE = num_random_bytes;
    }
    try {
	random_bytes_buffer = new unsigned char[RS_RB_BUFFER_SIZE];
	selected_list = new bool[N]{};
    } catch (std::bad_alloc&){
	printf("Allocating memory failed in RS_M2\n");
    }
    getBulkRandomBytes((unsigned char*)random_bytes_buffer, RS_RB_BUFFER_SIZE);
    random_bytes_buffer_ptr_end = (uint32_t*)(random_bytes_buffer + RS_RB_BUFFER_SIZE);
#else
    try {
	random_bytes_buffer = new unsigned char[num_random_bytes];
	selected_list = new bool[N]{};
    } catch (std::bad_alloc&){
	printf("Allocating memory failed in RS_M2\n");
    }

    getBulkRandomBytes((unsigned char*)random_bytes_buffer, num_random_bytes);
#endif

    random_bytes_buffer_ptr = (uint32_t*) random_bytes_buffer;
    FOAV_SAFE_CNTXT(RS_M2_opt, num_random_bytes)
	FOAV_SAFE2_CNTXT(RS_M2_opt, N, block_size)

	FOAV_SAFE_CNTXT(RS_M2_opt, block_size)
	if(block_size==4){
	    RecursiveShuffle_M2_inner<OSWAP_4>(buf, N, block_size, selected_list);
	} else if(block_size==8){
	    RecursiveShuffle_M2_inner<OSWAP_8>(buf, N, block_size, selected_list);
	} else if(block_size%16==0) {
	    RecursiveShuffle_M2_inner<OSWAP_16X>(buf, N, block_size, selected_list);
	} else {
	    RecursiveShuffle_M2_inner<OSWAP_8_16X>(buf, N, block_size, selected_list);
	}

    delete []random_bytes_buffer;
    delete []selected_list;

    ocall_clock(&t1);
    double ptime = ((double)(t1-t0))/1000.0;
    return ptime;
}


void enclave_debug_print(const char* msg) {
    ocall_print_string(msg);
}


void print_buffer(const unsigned char* buffer, uint32_t size, uint32_t N){
    for (int i = 0; i < N; i++) {
	uint64_t lbl = *((uint64_t*)(buffer + i * size));

	char msg[64];
	snprintf(msg, sizeof(msg), "block %d label = %llu\n", i, (unsigned long long)lbl);
	enclave_debug_print(msg);
    }
}


void print_labels_from_buffer(const unsigned char* buffer, uint32_t N, size_t block_size) {
    for (uint32_t i = 0; i < N; ++i) {
        const unsigned char* block = buffer + (size_t)i * block_size;

        uint32_t lbl = 0;
        // 安全に4バイトコピーして解釈（アラインメントを気にしない）                                                              
        std::memcpy(&lbl, block, sizeof(uint32_t));

        char msg[128];
        std::snprintf(msg, sizeof(msg), "block %u label = %u\n", i, (unsigned)lbl);
        enclave_debug_print(msg);
    }
}


inline void print_q32_32(i64 x)
{
    i64 ip = x >> 32;

    u64 frac = (u64)(x < 0 ? -x : x) & 0xffffffffULL;

    u64 frac_dec = (frac * 1000000000ULL) >> 32;

    char buf[64];
    std::snprintf(buf, sizeof(buf),
                  "%" PRId64 ".%09" PRIu64,
                  ip, frac_dec);

    enclave_debug_print(buf);
    enclave_debug_print("\n");
}


inline void print_int(int x)
{
    char buf[32];
    std::snprintf(buf, sizeof(buf), "%d", x);
    enclave_debug_print(buf);
    enclave_debug_print("\n");
}


void enclave_debug_print_u32_vector(const std::vector<uint32_t>& v)
{
    char buf[256];

    for (size_t i = 0; i < v.size(); ++i) {
        int n = std::snprintf(
			      buf, sizeof(buf),
			      "vec[%zu] = %u\n",
			      i, (unsigned)v[i]
			      );
        if (n > 0) {
            ocall_print_string(buf);
        }
    }
}


void print_time(uint64_t start, uint64_t end, std::string str) {
    uint64_t elapsed_us = (end > start) ? (end - start) : 0;

    char buf_e[128];
    int n_e0 = snprintf(buf_e, sizeof(buf_e),
                        "%s  = %llu us\n",
                        str.c_str(),
                        (unsigned long long)elapsed_us);
    if (n_e0 > 0) {
        ocall_print_string(buf_e);
    }
}


std::vector<uint32_t> bufferToVector(const unsigned char* buffer, uint32_t N, size_t block_size) {
    std::vector<uint32_t> vec;
    vec.reserve(N);

    for (uint32_t i = 0; i < N; ++i) {
        const unsigned char* block = buffer + (size_t)i * block_size;
        uint64_t val = 0;
        std::memcpy(&val, block, sizeof(uint32_t)); // read first 4 bytes as label                                                
        vec.push_back(val);
    }
    return vec;
}


// caller must free() the returned pointer when done.                                                                             
unsigned char* vectorToBuffer(const std::vector<uint32_t>& vec, size_t block_size) {
    size_t N = vec.size();
    size_t bytes = N * block_size;
    unsigned char* buffer = (unsigned char*) malloc(bytes);
    if (!buffer) return nullptr;

    // For each block, write label in first 4 bytes, zero the rest.                                                               
    for (size_t i = 0; i < N; ++i) {
        unsigned char* block = buffer + i * block_size;
        // zero whole block first                                                                                                 
        std::memset(block, 0, block_size);
        // copy label (4 bytes)                                                                                                   
        uint32_t v = vec[i];
        std::memcpy(block, &v, sizeof(uint32_t));
        // If you need to preserve other fields (IV, inner ciphertext...), do so here.                                            
    }
    return buffer;
}
        

// === constant-time equality ===                                                                                                 
static inline uint64_t ct_eq(uint64_t a, uint64_t b) {
    uint64_t x = a ^ b;
    return (uint64_t)(~((x | -x) >> 63)) & 1;
}



//===================== main routine in Enclave =====================================      

double DecryptAndShuffleM1(unsigned char *encrypted_buffer, uint32_t N, uint32_t d, uint32_t flag,size_t encrypted_block_size, unsigned char *result_buffer, enc_ret *ret) {

  
    // Decrypt buffer to decrypted_buffer
    unsigned char *decrypted_buffer = NULL;
    size_t decrypted_block_size = decryptBuffer(encrypted_buffer, N, encrypted_block_size, &decrypted_buffer);

  
    //====  transform buffer to vector  ====
    std::vector<uint32_t> D = bufferToVector(decrypted_buffer, N, decrypted_block_size);
    size_t n = D.size(); // N と同じ

  
    //====  time measurement parameters  ====
    uint64_t start = 0, end = 0;
    uint64_t elapsed_us = 0;
    char buf_e[128];

    //====  flags for expermiments  ====                                                                 
    int alg_f, type_f, geo_f;
    int rst = flag_ctl(flag, alg_f, type_f, geo_f);
    if(rst == 0) enclave_debug_print("bad flag. see the flag table!");


    //====  parameter settings ====
    int a10, a11, a20, a21, a30, a31;
    int p1, p2, p3;
    i64 beta_fx, ql_fx, qr_fx, qzl_fx, qzr_fx,qwl_fx, qwr_fx ;
    int lambda, nu, nuz, nuw, kappa;

    parameter_set(n, d, alg_f, type_f, geo_f,
                  kappa, nu, nuz, nuw, lambda,
                  beta_fx, ql_fx, qr_fx, qzl_fx, qzr_fx, qwl_fx, qwr_fx,
                  p1, p2, p3, a10, a11, a20, a21, a30, a31);
       

    int tu = 0;
    if (alg_f==1) tu = 1;
    if (alg_f==22) tu = 2;
    if (alg_f==23) tu = 3;

    std::vector<unsigned char> tmp;
 
    for (int i = 1; i <= tu; i++){ 
    
	//aoi step 1
	ocall_get_time(&start);

	std::vector<uint32_t> DD;
	DD.reserve(n);
	std::vector<uint32_t> x;
	x.reserve(n);

	if (tu == 1){
	    DD = D;
	}else if (tu==2 & i==1){
	    enclave_debug_print("do this\n");
	    DD = apply_hash(D,a11, a10, p1, (u32)n);
	}else if (tu==2 & i==2){
	    DD = apply_hash(D, a21, a20, p2, (u32)n);
	}else if (tu==3 & i==1){
	    DD  = apply_hash(D, a11, a10, p1, (u32)n);
	}else if (tu==3 & i==2){
	    DD = apply_hash(D, a21, a20, p2, (u32)n);
	}else if (tu==3 & i==3){
	    DD  = apply_hash(D, a31, a30, p3, (u32)n);
	}

  
	const uint32_t SENTINEL = (uint32_t)0;

    
	std::vector<uint32_t> a1(n), a2(n);
	for (size_t i = 0; i < n; ++i) {
	    a1[i] = DD[i];
	    a2[i] = SENTINEL;
	}

	for (size_t i = 0; i < n; ++i) {
	    uint64_t rnd;
	    sgx_read_rand((unsigned char*)&rnd, sizeof(rnd));
	    i64 rnd_fx = (i64)(rnd >> (64 - FRAC));
	    uint64_t mask = ocmp_geq_i64(rnd_fx, beta_fx);
	
	    uint32_t xx = a1[i];
	    uint32_t yy = a2[i];
	    oswap_u32(xx, yy, mask);
	    a1[i] = xx;
	    a2[i] = yy;

	    x.push_back((uint32_t)a1[i]);
	}

    
	ocall_get_time(&end);
	print_time(start, end, "step1");

      
	// step 2
	ocall_get_time(&start);

	std::vector<uint32_t> zi_list;
	std::vector<uint32_t> wi_list;

	if((alg_f==22) || (alg_f==23)){
	    d = n;   
	}
  
	if (type_f==2 || type_f==3){  // LNF, LNF*
	    zi_list.resize(d);
	    wi_list.resize(d);

	    for (size_t i = 0; i < d; ++i) {
		uint64_t rndz;
		sgx_read_rand((unsigned char*)&rndz, sizeof(rndz));
		i64 rndz_fx = (i64)(rndz >> (64 - FRAC));
      
		if(geo_f==0){
		    zi_list[i] = AGeo_oblivious(rndz_fx, nuz, qzl_fx, qzr_fx); 
		}else if(geo_f==1){
		    zi_list[i] = one_Geo_oblivious(rndz_fx, qzr_fx); 
		}
      

		if (type_f==3){ 
		    uint64_t rndw;
		    sgx_read_rand((unsigned char*)&rndw, sizeof(rndw));
		    i64 rndw_fx = (i64)(rndw >> (64 - FRAC));

		    wi_list[i] = AGeo_oblivious(rndw_fx, nuw, qwl_fx, qwr_fx);
		}
	    }
	}

	std::vector<uint32_t> xtilde;
	u32 k_max;
  
	if (type_f==1){ //UD
	    k_max = 0;  // nop
	    xtilde.reserve(lambda);
	}
  
	if (type_f==2){ //LNF
	    k_max = kappa;
	    xtilde.reserve(d * (size_t)k_max);
	}
  
	if (type_f==3){ //LNF*
	    k_max = 0;  
	    u32 zi_len = std::accumulate(zi_list.begin(), zi_list.end(),uint64_t{0});
	    u32 wi_len = std::accumulate(wi_list.begin(), wi_list.end(),uint64_t{0});
	    xtilde.reserve(zi_len + wi_len);
	}

	if(type_f==1){
	    for (uint32_t t = 0; t < lambda; ++t){
		xtilde.push_back((u32)randomInt(d));
	    }
	}
  
  
    
	//LNF LNF* AG 1G
	if(type_f==2 || type_f==3){
	    for (size_t i = 1; i <= d; ++i) {

		//LNF LNF*
		uint32_t zi;
		zi = zi_list[i-1];

		//LNF*
		if(type_f==3){
		    uint32_t wi;
		    wi = wi_list[i-1];
		    k_max = zi + wi;
		}
	
		std::vector<uint64_t> ak(k_max, (uint32_t)SENTINEL);
        
		for (uint32_t t = 0; t < k_max; ++t) {
		    uint64_t mask = ocmp_geq_u32(zi, t + 1);
		    uint32_t cur  = ak[t];
		    uint32_t newv = (uint32_t)i; //aoi ?
		    ak[t] = oselect_u32(cur, newv, mask);
		}

		for (uint32_t t = 0; t < k_max; ++t){
		    xtilde.push_back(ak[t]);
		}
	    }
	}

	x.reserve(x.size() + xtilde.size());
	x.insert(x.end(), xtilde.begin(), xtilde.end());
  
	ocall_get_time(&end); print_time(start, end, "step2");

	unsigned char* updated_buffer = vectorToBuffer(x, decrypted_block_size);
	print_int(x.size());

	// step 3 aoi

	ocall_get_time(&start);

	PRB_pool_init(1);
	RecursiveShuffle_M1(updated_buffer, N+xtilde.size(), decrypted_block_size);
  
	ocall_get_time(&end); print_time(start, end, "step3");

	PRB_pool_shutdown();
  
	free(decrypted_buffer); 
    }

    return(1.0);
}


double DecryptAndShuffleM2(unsigned char *encrypted_buffer, size_t N, size_t encrypted_block_size, size_t nthreads, unsigned char *result_buffer, enc_ret *ret) {
 
    // Decrypt buffer to decrypted_buffer
    unsigned char *decrypted_buffer = NULL;
    size_t decrypted_block_size = decryptBuffer(encrypted_buffer, N, encrypted_block_size, &decrypted_buffer);

    long t0, t1;
    ocall_clock(&t0);

    // ShuffleM2 on decrypted_buffer
    PRB_pool_init(nthreads);
    RecursiveShuffle_M2_parallel(decrypted_buffer, N, decrypted_block_size, nthreads);

    ocall_clock(&t1);
    // Encrypt buffer to result_buffer
    encryptBuffer(decrypted_buffer, N, decrypted_block_size, result_buffer);
    PRB_pool_shutdown();

#ifdef TIME_MARKHALF
    printf("Time taken in MarkHalf calls = %f\n", MARKHALF_TIME);
#endif

    free(decrypted_buffer); 
    double ptime = ((double)(t1-t0))/1000.0;
    ret->OSWAP_count = OSWAP_COUNTER;
    ret->sort_time = ptime;

    return(ptime);
}
