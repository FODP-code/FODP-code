#include <stdexcept>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <cstdlib>
#include <openssl/err.h>
#include <math.h>
#include "Application.hpp"
#include "gcm.h"
#include <fstream>
#include <math.h>
#include <sstream>
#include <cfloat>
#include <limits>

#include <iostream>
#include <vector>

#include <cstdio>
#include <cstdint>
#include <ctime>
#include <sys/time.h>

#include <algorithm>

#define NUM_ARGUMENTS_REQUIRED_1 4
#define NUM_ARGUMENTS_REQUIRED_2 7

// IV = 12 bytes, TAG = 16 bytes for AES-GCM
// So data component needs to be atleast >28 bytes large to do 0-encrypted integrity check
// We use 32 as it is the next fit for the block sizes supported by our library.
#define DATA_ENCRYPT_MIN_SIZE 40

// Global parameters that are to be supplied by the script that runs this application:
size_t N;
uint32_t d;

// BLOCK_SIZE > 8 (bytes), and should be a multiple of 16 bytes (For OSWAP to work) 
size_t BLOCK_SIZE;
size_t REPEAT;
bool ENCRYPTION=true;

uint64_t NUM_ZERO_BYTES;
unsigned char *zeroes;
char *data;
int flag;  // control flag   

//NOTE: Take this off if we dont care about depth
int MIN_D=1;

void parseCommandLineArguments(int argc, char *argv[]){
    data = argv[1]; 
    d = atoi(argv[2]); 
    flag = atoi(argv[3]);
    BLOCK_SIZE = 128; // 128 is standard

    REPEAT = 1;
}

//aoi: read input data (vector<int>)
std::vector<int> read_list(const std::string& filename) {
    std::ifstream ifs(filename);
    std::vector<int> result;
    if (!ifs) {
        std::cerr << "Error: cannot open file for reading.\n";
        return result;
    }

    int x;
    while (ifs >> x) {
        result.push_back(x);
    }
    return result;
}

//aoi: encl debug
void ocall_print_string(const char* str) {
    printf("[enclave] %s\n", str);
}

//aoi: time measurement
extern "C" void ocall_get_time(uint64_t* t)
{
    if (t == nullptr) return;
    struct timespec ts;
    // CLOCK_MONOTONIC_RAW is preferred if available
    clock_gettime(CLOCK_MONOTONIC_RAW, &ts);
    *t = (uint64_t)ts.tv_sec * 1000000ULL + (uint64_t)(ts.tv_nsec / 1000ULL);
}



int main(int argc, char *argv[]){

    parseCommandLineArguments(argc, argv);

    std::vector<int> input_list = read_list(std::string(data) + ".txt");
    N = input_list.size(); 
    int d_max = *std::max_element(input_list.begin(), input_list.end()); 

    std::cout << "n:" << N << "\n";
    std::cout << "d:" << d << "\n";
    std::cout << "d_max:" << d_max << "\n";
 
  
    // Initialize libcrypto
    OpenSSL_add_all_algorithms();
    ERR_load_crypto_strings();

    int randfd = open("/dev/urandom", O_RDONLY);
    if (randfd < 0) {
	throw std::runtime_error("Cannot open /dev/urandom");
    }

    // Initialize enclave
    OLib_initialize();

    // Load test AES keys into the enclave
    unsigned char inkey[16];
    unsigned char outkey[16];
    unsigned char datakey[16];
    read(randfd, inkey, 16);
    read(randfd, outkey, 16);
    read(randfd, datakey, 16);
    Enclave_loadTestKeys(inkey, outkey);

    const size_t ENC_BLOCK_SIZE = 12 + BLOCK_SIZE + 16; 

    unsigned char *buf;
    // For testing compact algs we need the original buffer and selected list at the end
    unsigned char *og_buf;
    size_t buflen, decbuflen;

    if(ENCRYPTION){
	buflen = N * ENC_BLOCK_SIZE;
    } else {
	buflen = N * BLOCK_SIZE;
    }
    buf = new unsigned char[buflen];

    if (buf == NULL) {
	printf("Allocating buffer memories in script Application failed!\n");
    }

  
    unsigned char *bufend = buf + buflen;

    bool *selected_list = NULL;
    int *key_counts;

    
    for (size_t r=0; r<REPEAT; r++) {


	key_counts = new int[d]{}; 



	size_t inc_ctr=0;

	if(ENCRYPTION) {
	    unsigned char iv[12];
	    read(randfd, iv, 12);

	    for (unsigned char *enc_block_ptr = buf; enc_block_ptr < bufend; enc_block_ptr += ENC_BLOCK_SIZE) {
		unsigned char block[BLOCK_SIZE] = {}; // Initializes to zero


		uint64_t rnd;

		rnd = input_list[inc_ctr++];
        
#ifdef SHOW_INPUT_KEYS
		printf("%ld, ",rnd);
#endif

		uint32_t rnd32 = rnd;
		memcpy(block, (unsigned char*) &rnd32, sizeof(rnd32));

		if(BLOCK_SIZE >= DATA_ENCRYPT_MIN_SIZE) {
		    NUM_ZERO_BYTES = BLOCK_SIZE-8-12-16;
		    zeroes = new unsigned char[NUM_ZERO_BYTES]();
        
		    (*((uint64_t*)iv))++;
		    memmove(block+8, iv, 12);

		    if ((NUM_ZERO_BYTES) != gcm_encrypt(zeroes, NUM_ZERO_BYTES, NULL, 0, datakey,
							block+8, 12, block+8+12, block+8+12+NUM_ZERO_BYTES)) {
			printf("Encryption failed\n");
			break;
		    }  
		}

		// Encrypt the chunk to the enclave      
		(*((uint64_t*)iv))++;
		memmove(enc_block_ptr, iv, 12);
		if (BLOCK_SIZE != gcm_encrypt(block, BLOCK_SIZE, NULL, 0, inkey,
					      enc_block_ptr, 12, enc_block_ptr+12, enc_block_ptr + 12 + BLOCK_SIZE)) {
		    printf("Encryption failed\n");
		    break;
		}
	    }
	} else {
	    uint64_t rnd;
	    for (unsigned char *block_ptr = buf; block_ptr < bufend; block_ptr += BLOCK_SIZE) {
		unsigned char block[BLOCK_SIZE] = {}; 
		rnd = inc_ctr++; 


		key_counts[rnd]+=1;

        
		memcpy(block, (unsigned char*) &rnd, sizeof(rnd));
		memcpy(block_ptr, block, BLOCK_SIZE);
	    }

	    size_t buflen = N * BLOCK_SIZE;
	    og_buf = new unsigned char[buflen];
	    memcpy(og_buf, buf, buflen); 
	} 
  
	// For the BOS modes we need a BRN_params structure that gets populated by BOS_optimize
	BRN_params params;
	bos_params bosparams;
	enc_ret ret;

    
        DecryptAndShuffleM1(buf, (uint32_t) N, (uint32_t) d, (uint32_t) flag, ENC_BLOCK_SIZE, buf, &ret);

    }
    return 0;
}
