#include "geo_dist.h"
#include <iostream>
#include <iostream>

#include "Enclave_t.h"
#include "util_obl.h"

// ==================================================
// AGeo_oblivious  (log-free, comparison only)
// ==================================================

// debug
void g_enclave_debug_print(const char* msg) {
    ocall_print_string(msg);
}


//u64 AGeo_oblivious(i64 r_fx, int nu, i64 ql_fx, i64 qr_fx)
u32 AGeo_oblivious(i64 r_fx, int nu, i64 ql_fx, i64 qr_fx)
{
    // ---------- eta ----------
    i64 ql_pow = ONE;
    for (int i = 0; i < nu; ++i)
        ql_pow = fx_mul(ql_pow, ql_fx);

    i64 one_minus_ql = ONE - ql_fx;
    i64 one_minus_qr = ONE - qr_fx;

    i64 term1 = fx_div(fx_mul(ql_fx, ONE - ql_pow), one_minus_ql);
    i64 term2 = fx_div(ONE, one_minus_qr);
    i64 eta   = term1 + term2;
    //std::cout << "\n" << "o-eta = " << ((double)eta / ONE) << "\n";

    // ---------- B ----------
    i64 rhs = ONE - fx_div(qr_fx, fx_mul(eta, one_minus_qr));
    //std::cout << "rhs = " << ((double)rhs / ONE);
    //std::cout << "  i64 rhs = " << rhs  << "\n";
    //std::cout << "r = " << ((double)r_fx / ONE) ;
    //std::cout << "  i64 r = " << r_fx  << "\n";

    u64 B   = ocmp_geq_i64(r_fx, rhs);
    //std::cout << "o-B = " << B << "\n";

    // g-ck
    //g_enclave_debug_print("ag1\n");
    // ---------- z_l ----------
    i64 inner_l =
        fx_mul(fx_mul(eta, one_minus_ql), r_fx)
        + fx_mul(ql_pow, ql_fx);

    const int KMAX = 64
    ;
    i64 ceil_l = oceil_log(inner_l, ql_fx, KMAX);
    //std::cout << "ceil = " << ceil_l  << "\n";
    
    i64 z_l    = (i64)nu * ONE - (ceil_l << FRAC) + ONE;
    //std::cout << "z_l = " << z_l  << "\n";

    // ---------- z_r ----------
    i64 inner_r =
        fx_mul(eta,
               fx_mul(one_minus_qr, ONE - r_fx));

    i64 floor_r = ofloor_log(inner_r, qr_fx, KMAX);
    i64 z_r     = (floor_r << FRAC) + (i64)nu * ONE;
    
    //std::cout << "o-zl_arg = " << ((double)inner_l / ONE) << "\n";
    //std::cout << "o-zr_arg = " << ((double)inner_r / ONE) << "\n";
    //std::cout << "o-zl = " << ((double)z_l / ONE) << "\n";
    //std::cout << "o-zr = " << ((double)z_r / ONE) << "\n";

    // ---------- select ----------
    i64 z_fx  = oselect_i64(z_l, z_r, B);
    i64 z_int = z_fx >> FRAC;

    u64 nonneg = is_nonneg_i64_mask(z_int);
    z_int = oselect_i64(0, z_int, nonneg);

     return (u32)z_int;
}


// ==================================================
// one_Geo_oblivious  (log-free, comparison only)
// ==================================================


// r : 0 < r < 1 （固定小数）
// q : 0 < q < 1 （固定小数）
u32 one_Geo_oblivious(i64 r_fx, i64 q_fx)
{
    i64 x_fx = ONE - r_fx;

    const int KMAX = 64;
    i64 z = ofloor_log(x_fx, q_fx, KMAX);

    // g-ck                                                                      
    //g_enclave_debug_print("1g\n");
     
    return (u32)z;
}
