#pragma once

#include <vector>
#include <cstdint>

// ----------------------------------
// 関数宣言
// ----------------------------------

int find_min_lambda(
    int d,
    double eps_max,
    double delta_max,
    double xi_step = 0.01,
    int lambda_max = 1000000000
);

int findPrimeInRange(int d);

int randomInt(int x);
  
std::vector<uint32_t> apply_hash(
    const std::vector<uint32_t>& x,
    uint32_t a1,
    uint32_t a0,
    uint32_t p,
    uint32_t b
);
