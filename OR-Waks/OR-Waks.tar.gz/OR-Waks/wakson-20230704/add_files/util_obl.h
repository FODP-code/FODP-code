#pragma once
#include <cmath>
#include "fx_common.h"
#include <cstring>
#include "sgx_trts.h"


// ================= float real ===================
inline i64 to_fx(double d) {
    const double scale = double(1ULL << FRAC);
    double scaled = d * scale;

    double pos = scaled + 0.5;
    double neg = scaled - 0.5;
    i64 r_pos = (i64)pos;
    i64 r_neg = (i64)neg;

    u64 bits;
    std::memcpy(&bits, &scaled, sizeof(bits));
    u64 sign = bits >> 63;
    i64 mask = -(i64)sign;
    return (r_pos & ~mask) | (r_neg & mask);
}


// ================= constants =================

static const i64 LN2_FX =
    (i64)(std::log(2.0) * (double)(1ULL << FRAC) + 0.5);

// ================= swap  =================

inline void oswap_u32(u32 &x, u32 &y, u64 mask)
{
    // mask: 0 or ~0ULL
    u32 t = (u32)((x ^ y) & (u32)mask);
    x ^= t;
    y ^= t;
}


// ================= select =================

inline i64 oselect_i64(i64 a, i64 b, u64 mask01) {
    i64 full = -(i64)(mask01 & 1ULL);
    return (a & ~full) | (b & full);
}

inline u32 oselect_u32(u32 x, u32 y, u64 mask)
{
    return x ^ ((x ^ y) & (u32)mask);
}

// ================= masks =================

inline u64 is_zero_i64_mask(i64 x) {
    u64 ux = (u64)x;
    u64 neg = (~ux) + 1ULL;
    return 1ULL ^ ((ux | neg) >> 63);
}

inline u64 is_nonneg_i64_mask(i64 x) {
    return 1ULL ^ (((u64)(x >> 63)) & 1ULL);
}

// ================= comparisons =================

inline u64 ocmp_geq_i64(i64 a, i64 b)
{
    u64 bit = (u64)(a - b) >> 63;  // 1 if a<b
    return 0ULL - (bit ^ 1ULL);    // a>=b → ~0, a<b → 0
}

inline u64 ocmp_gt_i64(i64 a, i64 b) {
    i64 diff = a - b;
    u64 sign = ((u64)diff >> 63) & 1ULL;
    u64 nz   = ((u64)(diff | -diff) >> 63) & 1ULL;
    return nz & (1ULL ^ sign);
}

inline u64 ocmp_geq_u32(u32 x, u32 y)
{
    // x >= y ⇔ (x - y) の borrow が発生しない
    // borrow bit = MSB of (x - y) when done in unsigned
    u64 diff = (u64)x - (u64)y;
    u64 ge = ~(diff >> 63) & 1;   // 1 if x>=y, 0 otherwise
    return 0 - ge;                // 0 or ~0
}

// ================= fixed-point =================

inline i64 fx_mul(i64 a, i64 b) {
    return (i64)(((i128)a * (i128)b) >> FRAC);
}

inline i64 fx_div(i64 a, i64 b) {
    u64 neg = ((a ^ b) >> 63) & 1ULL;
    u128 ua = (u128)(a < 0 ? -a : a);
    u128 ub = (u128)(b < 0 ? -b : b);
    i64 r = (i64)((ua << FRAC) / ub);
    return oselect_i64(r, -r, neg);
}

// ================ floor / ceil - log =============

inline double from_fx(i64 x) {
    return (double)x / (double)ONE;
}

static inline u64 ocmp_le_i64(i64 a, i64 b)
{
    // a <= b  <=>  !(a > b)
    return 1ULL ^ ocmp_gt_i64(a, b);
}


inline i64 ofloor_log(i64 x_fx, i64 y_fx, int KMAX)
{
    i64 best = 0;  // start (-1 before)    
    i64 yk   = ONE;    

    for (int k = 0; k <= KMAX; ++k) {  // 0 以上に clamp 
        // cond1 = (y^k >= x)
        u64 cond1 = ocmp_geq_i64(yk, x_fx);

        // cond2 = (k > best)
        u64 cond2 = ocmp_gt_i64((i64)k, best);

        // update = cond1 && cond2
        u64 update = cond1 & cond2;

        // if update: best = k
        best = oselect_i64(best, (i64)k, update);

        yk = fx_mul(yk, y_fx);
    }
    return best;
}


inline i64 oceil_log(i64 x_fx, i64 y_fx, int KMAX)
{
    i64 best  = KMAX + 1;  // 値が未定
    u64 found = 0;         
    i64 yk    = ONE;        

    for (int k = 0; k <= KMAX; ++k) {  // 0 以上に clamp 
        // cond = (y^k <= x)
        u64 cond = ocmp_le_i64(yk, x_fx);

        u64 update = cond & (~found);

        // 最初に条件を満たした k を保存
        best  = oselect_i64(best, (i64)k, update);
        found = found | cond;

        yk = fx_mul(yk, y_fx);
    }
    return best;
}


// ==== ヒストグラム用 util ====

inline double ORAND_REAL()
{
    u64 r;
    sgx_read_rand((unsigned char*)&r, sizeof(r));

    // 53bit に制限
    r &= ((1ULL << 53) - 1);

    return (double)(r + 1) / (double)((1ULL << 53) + 1);
}



inline int64_t floor_ln(double x)
{
    // 前提: x > 0
    i64 x_fx = to_fx(x);

    // log2(x) を fixed-point で floor
    // y = 2
    i64 log2_floor = ofloor_log(
        x_fx,
        (i64)(2.0 * (double)ONE),  // y_fx = 2
        /*KMAX=*/60
    );

    // ln(x) = log2(x) * ln(2)
    i64 ln_fx = fx_mul(log2_floor * ONE, LN2_FX);

    // floor なので整数部を返す
    return (int64_t)(ln_fx >> FRAC);
}


inline uint64_t ORAND_NATS(uint64_t x)
{
    u64 r;
    sgx_read_rand((unsigned char*)&r, sizeof(r));

    __uint128_t m = ( __uint128_t )r * ( __uint128_t )x;
    return (uint64_t)(m >> 64);
}


