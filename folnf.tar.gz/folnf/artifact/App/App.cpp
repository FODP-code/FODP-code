#include <stdio.h>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <stdint.h>
#include <string.h>
#include <algorithm>

#include "sgx_urts.h"
#include "Enclave_u.h"
#include "../Include/common.h"

static const uint8_t AES_KEY[AES_KEY_SIZE] = {
					      0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,
					      0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f
};

uint32_t d;
char* data;  // data file name
int flag;  // control flag


void parseCommandLineArguments(int argc, char *argv[]){
    data = argv[1];
    d = atoi(argv[2]);
    flag = atoi(argv[3]);
}

// read input data (vector<int>)                                                                   
std::vector<uint32_t> read_list(const std::string& filename) {
    std::ifstream ifs(filename);
    std::vector<uint32_t> result;
    if (!ifs) {
        std::cerr << "Error: cannot open file for reading.\n";
        return result;
    }

    uint32_t x;
    while (ifs >> x) {
        result.push_back(x);
    }
    return result;
}

// encl debug                                                              
                                                                                                       
void ocall_print_string(const char* str) {
    printf("[enclave] %s\n", str);
}

// time measurement                                                                                
extern "C" void ocall_get_time(uint64_t* t)
{
    if (t == nullptr) return;
    struct timespec ts;
    // CLOCK_MONOTONIC_RAW is preferred if available                                                   
    clock_gettime(CLOCK_MONOTONIC_RAW, &ts);
    *t = (uint64_t)ts.tv_sec * 1000000ULL + (uint64_t)(ts.tv_nsec / 1000ULL);
}


int main(int argc, char *argv[]) {
    parseCommandLineArguments(argc, argv);
  
    sgx_enclave_id_t eid;
    sgx_launch_token_t token = {0};
    int updated = 0;

     sgx_status_t create_status =  sgx_create_enclave("../Enclave/enclave.signed.so", 1, &token, &updated, &eid, NULL);
    if (create_status != SGX_SUCCESS) {
	printf("my Enclave creation failed: 0x%x\n", create_status);
	return -1;
    }

    
    sgx_create_enclave("enclave.signed.so", 1, &token, &updated, &eid, NULL);

    // ---- plaintext vector ----
    std::cout <<std::string(data);
     std::vector<uint32_t> vec = read_list(std::string(data) + ".txt");

    uint32_t len = vec.size() * sizeof(uint32_t); 
    int d_max = *std::max_element(vec.begin(), vec.end());
    size_t n = vec.size();
    
    std::cout << "n:" << n << "\n";
    std::cout << "d:" << d << "\n";
    std::cout << "d_max:" << d_max << "\n";

    

    // ---- AES-GCM encrypt ----
    uint8_t iv[IV_SIZE];
    RAND_bytes(iv, IV_SIZE);

    std::vector<uint8_t> ciphertext(len);
    uint8_t tag[TAG_SIZE];

    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    EVP_EncryptInit_ex(ctx, EVP_aes_128_gcm(), NULL, AES_KEY, iv);

    int outlen;
    int len1 = 0, len2 = 0;
    EVP_EncryptUpdate(ctx, ciphertext.data(), &len1,
		      (uint8_t*)vec.data(), len);
    EVP_EncryptFinal_ex(ctx, ciphertext.data() + len1, &len2);
    int cipher_len = len1 + len2;
    EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_GET_TAG, TAG_SIZE, tag);
 
    // ---- enclave decrypt ----
    std::vector<uint8_t> plaintext(len);
    sgx_status_t ecall_ret;
    sgx_status_t status = decrypt_vector(
					 eid,
					 &ecall_ret,        
					 len,               
					 iv,                
					 ciphertext.data(), 
					 tag,               
					 plaintext.data(),  
					 d,
					 flag
					 );

    
    if (status != SGX_SUCCESS || ecall_ret != SGX_SUCCESS) {
        printf("ECALL failed! status: %#x, ecall_ret: %#x\n", status, ecall_ret);
    } 
    // ---- verify first 8----
    /*
    uint32_t* out = (uint32_t*)plaintext.data();
    printf("first 8 of Shuffled : ");
    for (size_t i=0;i<8;i++) {
        printf("%u ", out[i]);
    }
    printf("\n");
    */
    
    sgx_destroy_enclave(eid);
}
