#include "Enclave_u.h"
#include <errno.h>

typedef struct ms_decrypt_vector_t {
	sgx_status_t ms_retval;
	uint32_t ms_len;
	uint8_t* ms_iv;
	uint8_t* ms_ciphertext;
	uint8_t* ms_tag;
	uint8_t* ms_plaintext;
	uint32_t ms_d;
	int ms_flag;
} ms_decrypt_vector_t;

typedef struct ms_ocall_print_string_t {
	const char* ms_str;
} ms_ocall_print_string_t;

typedef struct ms_ocall_get_time_t {
	uint64_t* ms_t;
} ms_ocall_get_time_t;

static sgx_status_t SGX_CDECL Enclave_ocall_print_string(void* pms)
{
	ms_ocall_print_string_t* ms = SGX_CAST(ms_ocall_print_string_t*, pms);
	ocall_print_string(ms->ms_str);

	return SGX_SUCCESS;
}

static sgx_status_t SGX_CDECL Enclave_ocall_get_time(void* pms)
{
	ms_ocall_get_time_t* ms = SGX_CAST(ms_ocall_get_time_t*, pms);
	ocall_get_time(ms->ms_t);

	return SGX_SUCCESS;
}

static const struct {
	size_t nr_ocall;
	void * table[2];
} ocall_table_Enclave = {
	2,
	{
		(void*)Enclave_ocall_print_string,
		(void*)Enclave_ocall_get_time,
	}
};
sgx_status_t decrypt_vector(sgx_enclave_id_t eid, sgx_status_t* retval, uint32_t len, uint8_t* iv, uint8_t* ciphertext, uint8_t* tag, uint8_t* plaintext, uint32_t d, int flag)
{
	sgx_status_t status;
	ms_decrypt_vector_t ms;
	ms.ms_len = len;
	ms.ms_iv = iv;
	ms.ms_ciphertext = ciphertext;
	ms.ms_tag = tag;
	ms.ms_plaintext = plaintext;
	ms.ms_d = d;
	ms.ms_flag = flag;
	status = sgx_ecall(eid, 0, &ocall_table_Enclave, &ms);
	if (status == SGX_SUCCESS && retval) *retval = ms.ms_retval;
	return status;
}

