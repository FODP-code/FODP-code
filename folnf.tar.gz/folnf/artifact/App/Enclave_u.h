#ifndef ENCLAVE_U_H__
#define ENCLAVE_U_H__

#include <stdint.h>
#include <wchar.h>
#include <stddef.h>
#include <string.h>
#include "sgx_edger8r.h" /* for sgx_status_t etc. */


#include <stdlib.h> /* for size_t */

#define SGX_CAST(type, item) ((type)(item))

#ifdef __cplusplus
extern "C" {
#endif

#ifndef OCALL_PRINT_STRING_DEFINED__
#define OCALL_PRINT_STRING_DEFINED__
void SGX_UBRIDGE(SGX_NOCONVENTION, ocall_print_string, (const char* str));
#endif
#ifndef OCALL_GET_TIME_DEFINED__
#define OCALL_GET_TIME_DEFINED__
void SGX_UBRIDGE(SGX_NOCONVENTION, ocall_get_time, (uint64_t* t));
#endif

sgx_status_t decrypt_vector(sgx_enclave_id_t eid, sgx_status_t* retval, uint32_t len, uint8_t* iv, uint8_t* ciphertext, uint8_t* tag, uint8_t* plaintext, uint32_t d, int flag);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif
