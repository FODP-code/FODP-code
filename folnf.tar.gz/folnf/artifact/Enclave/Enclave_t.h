#ifndef ENCLAVE_T_H__
#define ENCLAVE_T_H__

#include <stdint.h>
#include <wchar.h>
#include <stddef.h>
#include "sgx_edger8r.h" /* for sgx_ocall etc. */


#include <stdlib.h> /* for size_t */

#define SGX_CAST(type, item) ((type)(item))

#ifdef __cplusplus
extern "C" {
#endif

sgx_status_t decrypt_vector(uint32_t len, uint8_t* iv, uint8_t* ciphertext, uint8_t* tag, uint8_t* plaintext, uint32_t d, int flag);

sgx_status_t SGX_CDECL ocall_print_string(const char* str);
sgx_status_t SGX_CDECL ocall_get_time(uint64_t* t);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif
