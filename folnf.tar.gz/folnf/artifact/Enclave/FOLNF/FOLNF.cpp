#include "Enclave_t.h"
#include "sgx_tcrypto.h"
#include <stdint.h>
#include <vector>
#include <string>
#include <stdio.h>
#include <inttypes.h>
#include <numeric>

#include "../../Include/common.h"

#include "fx_common.h"
#include "util_obl.h"
#include "parameter_gen.h"
#include "parameter_set.h"
#include "geo_dist.h"
#include "Recursive_OR_Shuffle.h"
#include "block.hpp"


static const sgx_aes_gcm_128bit_key_t AES_KEY = {
						 0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,
						 0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f
};


// === print utility for debug  === 
void enclave_debug_print(const char* msg) {
    ocall_print_string(msg);
}

void print_q32_32(int64_t val) {
    char buf[64];

    int64_t val_integer = val >> 32;               
    uint64_t val_fraction = (uint64_t)(val & 0xFFFFFFFF); 

    std::snprintf(buf, sizeof(buf), "%ld.%09lu", (long)val_integer, (unsigned long)val_fraction);

    ocall_print_string(buf);
}

inline void print_int(int x)
{
    char buf[32];
    std::snprintf(buf, sizeof(buf), "%d", x);
    enclave_debug_print(buf);
    enclave_debug_print("\n");
}

void enclave_debug_print_u32_vector(const std::vector<uint32_t>& v)
{
    char buf[256];

    for (size_t i = 0; i < v.size(); ++i) {
        int n = std::snprintf(
			      buf, sizeof(buf),
			      "vec[%zu] = %u\n",
			      i, (unsigned)v[i]
			      );
        if (n > 0) {
            ocall_print_string(buf);}
    }
}


// === measurement ===
void print_time(uint64_t start, uint64_t end, std::string str) {
    uint64_t elapsed_us = (end > start) ? (end - start) : 0;

    char buf_e[128];
    int n_e0 = snprintf(buf_e, sizeof(buf_e),
                        "%s  = %llu us\n",
                        str.c_str(),
                        (unsigned long long)elapsed_us);
    if (n_e0 > 0) {
        ocall_print_string(buf_e);
    }
}


// === constant-time equality ===               
static inline uint64_t ct_eq(uint64_t a, uint64_t b) {
    uint64_t x = a ^ b;
    return (uint64_t)(~((x | -x) >> 63)) & 1;
}


// === oblivious Algorithm 4 ===

void oblivious_histogram(
			 const std::vector<uint64_t>& x,
			 uint64_t d,
			 double epsilon,
			 std::vector<int64_t>& fhat
			 ) {
    size_t n = x.size();
    fhat.assign(d, 0);

    // --- 1. Exact Histogram (Already Oblivious structure) ---
    for (size_t i = 0; i < n; ++i) {
        for (uint64_t j = 1; j <= d; ++j) {
            uint64_t m = ct_eq(x[i], j);
	    fhat[j-1] += (int64_t)m;
        }
    }

    // --- 2. Geometric Noise Generation (Using your fixed-point floor_ln) ---
       
    double r = ORAND_REAL();
      
    int64_t ln_1_minus_r = floor_ln(1.0 - r); 

    double denom = -2.0 / epsilon;
    int64_t z = (int64_t)((double)ln_1_minus_r / denom);

    // --- 3. Sign Selection s ∈ {−1, +1} ---
    int64_t s = (int64_t)(ORAND_NATS(2) * 2) - 1;

    // --- 4. Apply Noise to all bins ---
    for (uint64_t j = 0; j < d; ++j) {
        fhat[j] += s * z;
    }
}



//===================== main ecall function  =====================================    

sgx_status_t decrypt_vector(
			    uint32_t len,
			    uint8_t* iv,
			    uint8_t* ciphertext,
			    uint8_t* tag,
			    uint8_t* plaintext,
			    uint32_t d,
			    int flag
			    ) {
    // decryption
    sgx_status_t status = sgx_rijndael128GCM_decrypt(
						     &AES_KEY,
						     ciphertext,
						     len,
						     plaintext,
						     iv,
						     IV_SIZE,
						     NULL,
						     0,
						     (sgx_aes_gcm_128bit_tag_t*)tag
						     );

    if (status != SGX_SUCCESS) return status;

    uint32_t n = len / sizeof(uint32_t);

    uint32_t* raw_data = (uint32_t*)plaintext;
    std::vector<uint32_t> D(raw_data, raw_data + n); // input_data as vector

 
    //====  time measurement parameters  ====
    uint64_t start = 0, end = 0;
    uint64_t elapsed_us = 0;
    char buf_e[128];  

  
    //====  flags for expermiments  ====
    int alg_f, type_f, geo_f;
    int rst = flag_ctl(flag, alg_f, type_f, geo_f);
    if(rst == 0) enclave_debug_print("bad flag. see the flag table!");

  
    //====  parameter settings ====
    int a10, a11, a20, a21, a30, a31;
    int p1, p2, p3;
    i64 beta_fx, ql_fx, qr_fx, qzl_fx, qzr_fx,qwl_fx, qwr_fx ;
    int lambda, nu, nuz, nuw, kappa;

    parameter_set(n, d, alg_f, type_f, geo_f,
		  kappa, nu, nuz, nuw, lambda,
		  beta_fx, ql_fx, qr_fx, qzl_fx, qzr_fx, qwl_fx, qwr_fx,
		  p1, p2, p3, a10, a11, a20, a21, a30, a31);

    int tu = 0;
    if (alg_f==1) tu = 1;
    if (alg_f==22) tu = 2;
    if (alg_f==23) tu = 3;

    std::vector<unsigned char> tmp;
 
    for (int i = 1; i <= tu; i++){
    
	//step 1
	ocall_get_time(&start);

	std::vector<uint32_t> DD;
	DD.reserve(n);
	std::vector<uint32_t> x;
	x.reserve(n);

	if (tu == 1){
	    DD = D;
	}else if (tu==2 & i==1){
	    DD = apply_hash(D,a11, a10, p1, (u32)n);
	}else if (tu==2 & i==2){
	    DD = apply_hash(D, a21, a20, p2, (u32)n);
	}else if (tu==3 & i==1){
	    DD  = apply_hash(D, a11, a10, p1, (u32)n);
	}else if (tu==3 & i==2){
	    DD = apply_hash(D, a21, a20, p2, (u32)n);
	}else if (tu==3 & i==3){
	    DD  = apply_hash(D, a31, a30, p3, (u32)n);
	}

  
	const uint32_t SENTINEL = (uint32_t)0;
    
	std::vector<uint32_t> a1(n), a2(n);
	for (size_t i = 0; i < n; ++i) {
	    a1[i] = DD[i];
	    a2[i] = SENTINEL;
	}

	for (size_t i = 0; i < n; ++i) {
	    uint64_t rnd;
	    sgx_read_rand((unsigned char*)&rnd, sizeof(rnd));
	    i64 rnd_fx = (i64)(rnd >> (64 - FRAC));
	    uint64_t mask = ocmp_geq_i64(rnd_fx, beta_fx);
	
	    uint32_t xx = a1[i];
	    uint32_t yy = a2[i];
	    oswap_u32(xx, yy, mask);
	    a1[i] = xx;
	    a2[i] = yy;

	    x.push_back((uint32_t)a1[i]);
	}
    
	ocall_get_time(&end);
	print_time(start, end, "step1");

      
	//step 2
	ocall_get_time(&start);

	std::vector<uint32_t> zi_list;
	std::vector<uint32_t> wi_list;

	if((alg_f==22) || (alg_f==23)){
	    d = n;   
	    // d = n / 10;  // additional exp
	}
  
	if (type_f==2 || type_f==3){  // LNF, LNF*
	    zi_list.resize(d);
	    wi_list.resize(d);

	    for (size_t i = 0; i < d; ++i) {
		uint64_t rndz;
		sgx_read_rand((unsigned char*)&rndz, sizeof(rndz));
		i64 rndz_fx = (i64)(rndz >> (64 - FRAC));

      
		if(geo_f==0){
		    zi_list[i] = AGeo_oblivious(rndz_fx, nuz, qzl_fx, qzr_fx); 
		}else if(geo_f==1){
		    zi_list[i] = one_Geo_oblivious(rndz_fx, qzr_fx); 
		}
      
		if (type_f==3){ // D'(w) in LNF* at geo_f==1 is AGeo!
		    uint64_t rndw;
		    sgx_read_rand((unsigned char*)&rndw, sizeof(rndw));
		    i64 rndw_fx = (i64)(rndw >> (64 - FRAC));
		    wi_list[i] = AGeo_oblivious(rndw_fx, nuw, qwl_fx, qwr_fx);
		}
	    }
	}

  
	std::vector<uint32_t> xtilde;
	u32 k_max;
  
	if (type_f==1){ // UD
	    k_max = 0;  // nop
	    xtilde.reserve(lambda);
	}
  
	if (type_f==2){ //LNF
	    k_max = kappa;  
	    xtilde.reserve(d * (size_t)k_max);
	}
  
	if (type_f==3){ //LNF*
	    k_max = 0;  //dyamic change
	    u32 zi_len = std::accumulate(zi_list.begin(), zi_list.end(),uint64_t{0});
	    u32 wi_len = std::accumulate(wi_list.begin(), wi_list.end(),uint64_t{0});
	    xtilde.reserve(zi_len + wi_len);
	}
  
	if(type_f==1){
	    for (uint32_t t = 0; t < lambda; ++t){
		xtilde.push_back((u32)randomInt(d));
	    }
	}
  
    
	//LNF LNF* AG 1G
	if(type_f==2 || type_f==3){
	    for (size_t i = 1; i <= d; ++i) {

		//LNF LNF*
		uint32_t zi;
		zi = zi_list[i-1];

		//LNF*
		if(type_f==3){
		    uint32_t wi;
		    wi = wi_list[i-1];
		    k_max = zi + wi;
		}

		std::vector<uint64_t> ak(k_max, (uint32_t)SENTINEL);
        
		for (uint32_t t = 0; t < k_max; ++t) {
		    uint64_t mask = ocmp_geq_u32(zi, t + 1);
		    uint32_t cur  = ak[t];
		    uint32_t newv = (uint32_t)i; //aoi ?
		    ak[t] = oselect_u32(cur, newv, mask);
		}

		for (uint32_t t = 0; t < k_max; ++t){
		    xtilde.push_back(ak[t]);
		}
	    }
	}

	// x = x + xtilde
	x.reserve(x.size() + xtilde.size());
	x.insert(x.end(), xtilde.begin(), xtilde.end());
  
	ocall_get_time(&end);
	print_time(start, end, "step2");

	enclave_debug_print(("shuffle size: " + std::to_string(x.size())).c_str());


	// step 3 

	ocall_get_time(&start);

	uint64_t root_seed;
	sgx_read_rand(reinterpret_cast<unsigned char*>(&root_seed), sizeof(root_seed));
	size_t base_size = 32;

	recursive_or_shuffle(x, base_size, root_seed);
  
	ocall_get_time(&end);
	print_time(start, end, "step3");
    }


    if(alg_f == 4){
	//-- Direct histgram Alg 4 --      
                   
	ocall_get_time(&start);      

	std::vector<uint32_t>& D32 = D;     
	std::vector<uint64_t> D64;      
	D64.reserve(D32.size());      
	for (uint32_t v : D32) {      
	    D64.push_back(static_cast<uint64_t>(v));        
	}      
	double epsilon = 0.8;         
	std::vector<int64_t> fhat;                                                                                   
	oblivious_histogram(D64, d, epsilon, fhat);      
             
	ocall_get_time(&end);      
	print_time(start, end, "histgram");               
    }


    // verification at untrusted
    memset(plaintext, 0, len);
      
    memcpy(plaintext, D.data(), 8 * sizeof(uint32_t));
    
    return SGX_SUCCESS;
}



