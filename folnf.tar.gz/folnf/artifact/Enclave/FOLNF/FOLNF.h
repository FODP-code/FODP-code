#ifndef FOLNF_H
#define FOLNF_H

#include <stdint.h>
#include "sgx_tcrypto.h"
#include "Enclave_t.h"

#define IV_SIZE 12
#define TAG_SIZE 16

sgx_status_t decrypt_vector(
    uint8_t* iv,
    uint8_t* ciphertext,
    uint32_t len,
    uint8_t* tag,
    uint8_t* plaintext
);

#endif
