#include <cstdint>
#include <vector>
#include <cassert>

#include "block.hpp"


inline void oswap_u32(uint32_t &a, uint32_t &b, uint64_t mask) {
    uint32_t tmp = (uint32_t)(mask) * (a ^ b);
    a ^= tmp;
    b ^= tmp;
}


inline void oswap_block(block &a, block &b, uint64_t mask) {
    uint32_t tmp = static_cast<uint32_t>(mask) * (a.value ^ b.value);
    a.value ^= tmp;
    b.value ^= tmp;
}

// =====================================================
// PRG (replaceable by sgx_read_rand)
// =====================================================
inline uint64_t prg_next(uint64_t &seed) {
    seed ^= seed >> 12;
    seed ^= seed << 25;
    seed ^= seed >> 27;
    return seed * 0x2545F4914F6CDD1DULL;
}

// =====================================================
// Base shuffle (small block, oblivious)
// =====================================================
void base_shuffle(std::vector<uint32_t> &A,
                  size_t l, size_t r,
                  uint64_t &seed) {
    for (size_t i = r; i > l; --i) {
        uint64_t rnd = prg_next(seed);
        size_t j = l + (rnd % (i - l + 1));

        uint32_t x = A[i];
        uint32_t y = A[j];

        // oblivious unconditional swap
        oswap_u32(x, y, 1);

        A[i] = x;
        A[j] = y;
    }
}

void base_shuffle_b(block *A,
                    size_t l, size_t r,
                    uint64_t &seed) {
    for (size_t i = r; i > l; --i) {
        uint64_t rnd = prg_next(seed);
        size_t j = l + (rnd % (i - l + 1));

        // oblivious unconditional swap
        oswap_block(A[i], A[j], 1);
    }
}


// =====================================================
// Frame (explicit stack, SGX-friendly)
// =====================================================
struct Frame {
    size_t   l;
    size_t   r;
    uint64_t seed;
    uint64_t expanded; // 0 or 1
};

// =====================================================
// Recursive ORShuffle (non-recursive, SGX-safe)
// =====================================================
void recursive_or_shuffle(std::vector<uint32_t> &A,
                          size_t base_size,
                          uint64_t root_seed) {
    assert(base_size >= 2);

    const size_t n = A.size();
    if (n <= 1) return;

    std::vector<Frame> stack;
    stack.reserve(2 * 64); //  O(log n) depth

    stack.push_back(Frame{0, n - 1, root_seed, 0});

    while (!stack.empty()) {
        Frame f = stack.back();
        stack.pop_back();

        size_t len = f.r - f.l + 1;

        // leaf
        if (len <= base_size) {
            uint64_t local_seed = f.seed;
            base_shuffle(A, f.l, f.r, local_seed);
            continue;
        }

        if (f.expanded == 0) {
            size_t mid = f.l + len / 2;

            // derive child seeds (deterministic)
            uint64_t seed_left  = prg_next(f.seed);
            uint64_t seed_right = prg_next(f.seed);

            // post-order
            stack.push_back(Frame{f.l, f.r, f.seed, 1});
            stack.push_back(Frame{mid, f.r, seed_right, 0});
            stack.push_back(Frame{f.l, mid - 1, seed_left, 0});
        } else {
            uint64_t local_seed = f.seed;
            base_shuffle(A, f.l, f.r, local_seed);
        }
    }
}


// =====================================================
// Recursive ORShuffle (block-based, non-recursive)
// =====================================================
void recursive_or_shuffle_b(block *A,
                            size_t n,
                            size_t base_size,
                            uint64_t root_seed) {
    assert(base_size >= 2);
    if (n <= 1) return;

    std::vector<Frame> stack;
    stack.reserve(2 * 64);

    stack.push_back(Frame{0, n - 1, root_seed, 0});

    while (!stack.empty()) {
        Frame f = stack.back();
        stack.pop_back();

        size_t len = f.r - f.l + 1;

        if (len <= base_size) {
            uint64_t local_seed = f.seed;
            base_shuffle_b(A, f.l, f.r, local_seed);
            continue;
        }

        if (f.expanded == 0) {
            size_t mid = f.l + len / 2;

            uint64_t seed_left  = prg_next(f.seed);
            uint64_t seed_right = prg_next(f.seed);

            stack.push_back(Frame{f.l, f.r, f.seed, 1});
            stack.push_back(Frame{mid, f.r, seed_right, 0});
            stack.push_back(Frame{f.l, mid - 1, seed_left, 0});
        } else {
            uint64_t local_seed = f.seed;
            base_shuffle_b(A, f.l, f.r, local_seed);
        }
    }
}
