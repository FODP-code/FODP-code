#pragma once
#include "util_obl.h"
#include "block.hpp"


void recursive_or_shuffle(std::vector<uint32_t> &A, size_t base_size, uint64_t root_seed);

void recursive_or_shuffle_b(block *A, size_t n, size_t base_size, uint64_t root_seed);
