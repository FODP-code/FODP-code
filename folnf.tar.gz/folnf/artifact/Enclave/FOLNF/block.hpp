#pragma once

#include <cstddef>
#include <cstdint>



constexpr size_t BLOCK_SIZE = 64;

struct block {
    uint32_t value;
    uint8_t  pad[BLOCK_SIZE - sizeof(uint32_t)];
};
