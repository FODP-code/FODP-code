#include "geo_dist.h"
#include <iostream>
#include <iostream>

#include "Enclave_t.h"
#include "util_obl.h"

// ==================================================
// AGeo_oblivious  (log-free, comparison only)
// ==================================================

// debug
void g_enclave_debug_print(const char* msg) {
    ocall_print_string(msg);
}


//u64 AGeo_oblivious(i64 r_fx, int nu, i64 ql_fx, i64 qr_fx)
u32 AGeo_oblivious(i64 r_fx, int nu, i64 ql_fx, i64 qr_fx)
{
    // ---------- eta ----------
    i64 ql_pow = ONE;
    for (int i = 0; i < nu; ++i)
        ql_pow = fx_mul(ql_pow, ql_fx);

    i64 one_minus_ql = ONE - ql_fx;
    i64 one_minus_qr = ONE - qr_fx;

    i64 term1 = fx_div(fx_mul(ql_fx, ONE - ql_pow), one_minus_ql);
    i64 term2 = fx_div(ONE, one_minus_qr);
    i64 eta   = term1 + term2;


    // ---------- B ----------
    i64 rhs = ONE - fx_div(qr_fx, fx_mul(eta, one_minus_qr));

    u64 B   = ocmp_geq_i64(r_fx, rhs);

    
    // ---------- z_l ----------
    i64 inner_l =
        fx_mul(fx_mul(eta, one_minus_ql), r_fx)
        + fx_mul(ql_pow, ql_fx);

    const int KMAX = 64 ;
    i64 ceil_l = oceil_log(inner_l, ql_fx, KMAX);
    
    i64 z_l    = (i64)nu * ONE - (ceil_l << FRAC) + ONE;

    
    // ---------- z_r ----------
    i64 inner_r =
        fx_mul(eta,
               fx_mul(one_minus_qr, ONE - r_fx));

    i64 floor_r = ofloor_log(inner_r, qr_fx, KMAX);
    i64 z_r     = (floor_r << FRAC) + (i64)nu * ONE;
    

    // ---------- select ----------
    i64 z_fx  = oselect_i64(z_l, z_r, B);
    i64 z_int = z_fx >> FRAC;

    u64 nonneg = is_nonneg_i64_mask(z_int);
    z_int = oselect_i64(0, z_int, nonneg);

     return (u32)z_int;
}


// ==================================================
// one_Geo_oblivious  (log-free, comparison only)
// ==================================================


u32 one_Geo_oblivious(i64 r_fx, i64 q_fx)
{
    i64 x_fx = ONE - r_fx;

    const int KMAX = 64;
    i64 z = ofloor_log(x_fx, q_fx, KMAX);

    return (u32)z;
}
