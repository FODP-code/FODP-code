#include "fx_common.h"
#include "parameter_gen.h"
#include "util_obl.h"


int flag_ctl(int flag, int &alg_f, int &type_f, int &geo_f){ 
    if(flag == 110){ alg_f = 1; type_f = 1;}
    else if(flag == 120){ alg_f = 1; type_f = 2; geo_f = 0;}
    else if(flag == 121){ alg_f = 1; type_f = 2; geo_f = 1;}
    else if(flag == 130){ alg_f = 1; type_f = 3; geo_f = 0;}
    else if(flag == 131){ alg_f = 1; type_f = 3; geo_f = 1;}
    else if(flag == 210){ alg_f = 22; type_f = 1;}
    else if(flag == 220){ alg_f = 22; type_f = 2; geo_f = 0;}
    else if(flag == 221){ alg_f = 22; type_f = 2; geo_f = 1;}
    else if(flag == 230){ alg_f = 22; type_f = 3; geo_f = 0;}
    else if(flag == 231){ alg_f = 22; type_f = 3; geo_f = 1;}
    else if(flag == 400){ alg_f = 4;}
    else {return 0;}

    return 1;
}

void parameter_set(u32 n, u32 d, int alg_f, int type_f, int geo_f,
		   int &kappa, int &nu, int &nuz, int &nuw, int &lambda,
		   i64 &beta_fx, i64 &ql_fx, i64 &qr_fx, i64 &qzl_fx, i64 &qzr_fx, i64 &qwl_fx, i64 &qwr_fx,
		   int &p1, int &p2, int &p3, int &a10, int &a11, int &a20, int &a21, int &a30, int &a31){

  
    if (alg_f==1){
	if(type_f==1) {
	  if(n==1000 && d==100){lambda = 3453878;}
	  else {lambda = 34538777;}
	}
	else if (type_f==2 && geo_f==0){
	    double beta = 1.0;
	    double qzl = 0.951229424500714;        
	    double qzr = 0.951229424500714;        
	    nuz = 507;
	    kappa = 1074;

	    beta_fx = to_fx(beta);
	    qzl_fx = to_fx(qzl);
	    qzr_fx = to_fx(qzr);

	}
	else if (type_f==2 && geo_f==1){
	    double beta = 0.048770575499286;
	    double qzl = 0.0;        
	    double qzr = 0.48750260351579;        
	    kappa = 40;

	    qzl_fx = to_fx(qzl);
	    qzr_fx = to_fx(qzr);
	    beta_fx = to_fx(beta);
	}
	else if (type_f==3 && geo_f==0){
	    double beta = 1.0;
	    double qzl = 0.951229424500714;        
	    double qzr = 0.951229424500714;        
	    nuz = 507;

	    beta_fx = to_fx(beta);
	    qzl_fx = to_fx(qzl);
	    qzr_fx = to_fx(qzr);

	    double qwl = 0.637628151621773;        
	    double qwr = 0.637628151621773;        
	    nuw = 60;

	    qwl_fx = to_fx(qwl);
	    qwr_fx = to_fx(qwr);
	}
	else if (type_f==3 && geo_f==1){
	    double beta = 0.048770575499286;
	    double qzl = 0.0;        
	    double qzr = 0.487502603515789;        

	    beta_fx = to_fx(beta);
	    qzl_fx = to_fx(qzl);
	    qzr_fx = to_fx(qzr);

	    double qwl = 0.143430596960281;        
	    double qwr = 0.0;        
	    //nuw = 14;
	    nuw = 13; // changed 1/24
      
	    qwl_fx = to_fx(qwl);
	    qwr_fx = to_fx(qwr);      
	}
    }
    
    if (alg_f==22){
	p1 = findPrimeInRange(d);
	a10 = randomInt(p1);
	a11 = randomInt(p1-1);
	p2 = findPrimeInRange(d);
	a20 = randomInt(p2);
	a21 = randomInt(p2-1);
    
	if(type_f==1) {
	  if(n==1000 && d==100){lambda = 3453878;}
	  else {lambda = 34538777;}
	}
	else if (type_f==2 && geo_f==0){
	    double beta = 1.0;
	    double qzl = 0.951229424500714;        
	    double qzr = 0.951229424500714;        
	    nuz = 507;
	    kappa = 1074;

	    beta_fx = to_fx(beta);
	    qzl_fx = to_fx(qzl);
	    qzr_fx = to_fx(qzr);

	}
	else if (type_f==2 && geo_f==1){
	    double beta = 0.048770575499286;
	    double qzl = 0.0;        
	    double qzr = 0.48750260351579;        
	    kappa = 40;

	    qzl_fx = to_fx(qzl);
	    qzr_fx = to_fx(qzr);
	    beta_fx = to_fx(beta);
	}
	else if (type_f==3 && geo_f==0){
	    double beta = 1.0;
	    double qzl = 0.951229424500714;        
	    double qzr = 0.951229424500714;        
	    nuz = 507;

	    beta_fx = to_fx(beta);
	    qzl_fx = to_fx(qzl);
	    qzr_fx = to_fx(qzr);

	    double qwl = 0.637628151621773;        
	    double qwr = 0.637628151621773;        
	    nuw = 60;

	    qwl_fx = to_fx(qwl);
	    qwr_fx = to_fx(qwr);
	}
	else if (type_f==3 && geo_f==1){
	    double beta = 0.048770575499286;
	    double qzl = 0.0;        
	    double qzr = 0.487502603515789;        

	    beta_fx = to_fx(beta);
	    qzl_fx = to_fx(qzl);
	    qzr_fx = to_fx(qzr);

	    double qwl = 0.143430596960281;        
	    double qwr = 0.0;        
	    // nuw = 14;
	    nuw = 13;  // changed 1/24
      
	    qwl_fx = to_fx(qwl);
	    qwr_fx = to_fx(qwr);
      
	}
    }
  
    if (alg_f==23){
	p1 = findPrimeInRange(d);
	a10 = randomInt(p1);
	a11 = randomInt(p1-1);
	p2 = findPrimeInRange(d);
	a20 = randomInt(p2);
	a21 = randomInt(p2-1);
	p3 = findPrimeInRange(d);
	a30 = randomInt(p3);
	a31 = randomInt(p3-1);
    
	if(type_f==1) {
	    lambda = find_min_lambda(d, 0.333333333333333, 0.000000000000333333333333333); //aoi excel top
	}
	else if (type_f==2 && geo_f==0){
	    double beta = 1.0;
	    double qzl = 0.846481724890614;        
	    double qzr = 0.846481724890614;        
	    nuz = 166;
	    kappa = 343;

	    u64 beta_fx = to_fx(beta);
	    u64 qzl_fx = to_fx(qzl);
	    u64 qzr_fx = to_fx(qzr);
	}
	else if (type_f==2 && geo_f==1){
	    double beta = 0.153518275109386;
	    double qzl = 0.0;        
	    double qzr = 0.4584295167832;        
	    kappa = 38;
      
	    u64 qzl_fx = to_fx(qzl);
	    u64 qzr_fx = to_fx(qzr);
	    u64 beta_fx = to_fx(beta);
	}
	else if (type_f==3 && geo_f==0){
	    double beta = 1.0;
	    double qzl = 0.920044414629323;        
	    double qzr = 0.920044414629323;        
	    nuz = 324;

	    u64 beta_fx = to_fx(beta);
	    u64 qzl_fx = to_fx(qzl);
	    u64 qzr_fx = to_fx(qzr);

	    double qwl = 0.920044414629323;        
	    double qwr = 0.920044414629323;        
	    nuw = 315;

	    u64 qwl_fx = to_fx(qwl);
	    u64 qwr_fx = to_fx(qwr);
	}
	else if (type_f==3 && geo_f==1){
	    double beta = 0.0799555853706769;
	    double qzl = 0.0;        
	    double qzr = 0.479178714627257;        

	    u64 beta_fx = to_fx(beta);
	    u64 qzl_fx = to_fx(qzl);
	    u64 qzr_fx = to_fx(qzr);

	    double qwl = 0.638535857039282;        
	    double qwr = 0.0;
	    nuw = 53;

	    u64 qwl_fx = to_fx(qwl);
	    u64 qwr_fx = to_fx(qwr);

	}
    }
}
