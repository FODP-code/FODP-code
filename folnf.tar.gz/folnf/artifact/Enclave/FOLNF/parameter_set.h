#include "fx_common.h"

int flag_ctl(int flag, int &alg_f, int &type_f, int &geo_f);

void parameter_set(u32 n,u32 d, int alg_f, int type_f, int geo_f,
		   int &kappa, int &nu, int &nuz, int &nuw, int &lambda,
                   i64 &beta_fx, i64 &ql_fx, i64 &qr_fx, i64 &qzl_fx, i64 &qzr_fx, i64 &qwl_fx, i64 &qwr_fx,
                   int &p1, int &p2, int &p3, int &a10, int &a11, int &a20, int &a21, int &a30, int &a31);
