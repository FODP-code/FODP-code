#pragma once
#include <stdint.h>

#define AES_KEY_SIZE 16
#define IV_SIZE 12
#define TAG_SIZE 16
